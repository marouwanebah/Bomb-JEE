package beans;

public class Partie {
	private int _numeroPartie;
	private String _dateCreationPartie;
	private String _gagnantPartie;
	private String _codeEtatPartie;
	private String _dateDebutPartie;
	private String _dateFinPartie;
	private String _codeLevelPartie;
	public Partie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int get_numeroPartie() {
		return _numeroPartie;
	}
	public void set_numeroPartie(int _numeroPartie) {
		this._numeroPartie = _numeroPartie;
	}
	public String get_dateCreationPartie() {
		return _dateCreationPartie;
	}
	public void set_dateCreationPartie(String _dateCreationPartie) {
		this._dateCreationPartie = _dateCreationPartie;
	}
	public String get_gagnantPartie() {
		return _gagnantPartie;
	}
	public void set_gagnantPartie(String _gagnantPartie) {
		this._gagnantPartie = _gagnantPartie;
	}
	public String get_codeEtatPartie() {
		return _codeEtatPartie;
	}
	public void set_codeEtatPartie(String _codeEtatPartie) {
		this._codeEtatPartie = _codeEtatPartie;
	}
	public String get_dateDebutPartie() {
		return _dateDebutPartie;
	}
	public void set_dateDebutPartie(String _dateDebutPartie) {
		this._dateDebutPartie = _dateDebutPartie;
	}
	public String get_dateFinPartie() {
		return _dateFinPartie;
	}
	public void set_dateFinPartie(String _dateFinParite) {
		this._dateFinPartie = _dateFinParite;
	}
	public String get_codeLevelPartie() {
		return _codeLevelPartie;
	}
	public void set_codeLevelPartie(String _codeLevelPartie) {
		this._codeLevelPartie = _codeLevelPartie;
	}
	
}
